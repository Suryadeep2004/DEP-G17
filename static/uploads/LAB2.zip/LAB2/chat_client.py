import socket
import threading

class ChatClient:
    def __init__(self, server_ip, server_port):
        self.server_ip = server_ip
        self.server_port = server_port
        self.client_socket = None
        self.username = None

    def listen_for_messages(self):
        while True:
            try:
                message = self.client_socket.recv(1024).decode()
                print(message)
            except:
                print("Error receiving message.")
                break

    def send_message(self):
        while True:
            message = input(f"{self.username} > ")
            self.client_socket.send(message.encode())
            if message == "/exit":
                break

    def start_client(self):
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client_socket.connect((self.server_ip, self.server_port))

        self.username = input("Enter your username: ")
        self.client_socket.send(self.username.encode())

        # Start receiving messages in a separate thread
        listen_thread = threading.Thread(target=self.listen_for_messages)
        listen_thread.start()

        # Start sending messages in the main thread
        self.send_message()

        self.client_socket.close()

# Run the client
if __name__ == "__main__":
    client = ChatClient("localhost", 12345)
    client.start_client()
