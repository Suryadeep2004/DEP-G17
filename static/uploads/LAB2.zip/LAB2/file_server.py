import socket
import os

def send_file(conn, filename):
    """Send the file to the client."""
    try:
        with open(filename, 'rb') as file:
            file_data = file.read(1024)
            while file_data:
                conn.send(file_data)
                file_data = file.read(1024)
        print(f"File {filename} sent successfully.")
    except Exception as e:
        print(f"Error while sending file: {e}")

def receive_file(conn, filename):
    """Receive a file from the client and save it."""
    try:
        with open(filename, 'wb') as file:
            file_data = conn.recv(1024)
            while file_data:
                file.write(file_data)
                file_data = conn.recv(1024)
        print(f"File {filename} received successfully.")
    except Exception as e:
        print(f"Error while receiving file: {e}")

def start_server(host='127.0.0.1', port=65432):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)
    print(f"Server listening on {host}:{port}...")

    while True:
        conn, addr = server_socket.accept()
        print(f"Connection from {addr} established.")
        conn.send(b"Welcome to the file server. Choose 'upload' or 'download'.")
        
        action = conn.recv(1024).decode()
        print(f"Action received: {action}")

        if action == 'upload':
            conn.send(b"Ready to receive file. Send filename to upload.")
            filename = conn.recv(1024).decode()
            print(f"Receiving file: {filename}")
            receive_file(conn, filename)
        elif action == 'download':
            conn.send(b"Send filename to download.")
            filename = conn.recv(1024).decode()
            if os.path.exists(filename):
                print(f"Sending file: {filename}")
                send_file(conn, filename)
            else:
                conn.send(b"File not found on server.")
        else:
            conn.send(b"Invalid action.")

        conn.close()

if __name__ == "__main__":
    start_server()
