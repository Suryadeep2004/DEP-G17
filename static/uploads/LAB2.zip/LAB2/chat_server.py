import socket
import threading

class ChatServer:
    def __init__(self):
        self.clients = {}  # Store active clients: {username: (client_socket, client_thread)}

    def handle_client(self, client_socket, client_address):
        # Get username from the client
        username = client_socket.recv(1024).decode()
        self.clients[username] = client_socket
        print(f"{username} has joined the chat.")

        # Notify all clients that a new user has joined
        self.broadcast(f"{username} has joined the chat!", username)

        try:
            while True:
                message = client_socket.recv(1024).decode()
                if not message:
                    break
                
                # Process message: Broadcast or private message
                if message.startswith("/all"):
                    self.broadcast(f"{username}: {message[4:].strip()}", username)
                elif message.startswith("/pm"):
                    _, recipient, *msg = message.split()
                    recipient = " ".join([recipient] + msg)
                    self.send_private_message(username, recipient)
                elif message == "/exit":
                    break
                else:
                    client_socket.send("Unknown command!\n".encode())
        finally:
            # Remove the client when they disconnect
            del self.clients[username]
            self.broadcast(f"{username} has left the chat.", username)
            client_socket.close()

    def broadcast(self, message, sender):
        """ Send a message to all clients except the sender. """
        for username, client_socket in self.clients.items():
            if username != sender:
                client_socket.send(message.encode())

    def send_private_message(self, sender, recipient_message):
        """ Send a private message to a specific user. """
        recipient, *msg = recipient_message.split()
        message = " ".join(msg)
        if recipient in self.clients:
            recipient_socket = self.clients[recipient]
            recipient_socket.send(f"Private message from {sender}: {message}\n".encode())
        else:
            sender_socket = self.clients[sender]
            sender_socket.send("Recipient not found!\n".encode())

    def start_server(self, host='localhost', port=12345):
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind((host, port))
        server_socket.listen(5)
        print(f"Server started on {host}:{port}")

        while True:
            client_socket, client_address = server_socket.accept()
            print(f"Connection from {client_address}")

            # Handle each client in a new thread
            client_thread = threading.Thread(target=self.handle_client, args=(client_socket, client_address))
            client_thread.start()

# Run the server
if __name__ == "__main__":
    chat_server = ChatServer()
    chat_server.start_server()
