import socket
import os

def upload_file(client_socket):
    """Upload a file to the server."""
    filename = input("Enter the name of the file to upload: ")
    if os.path.exists(filename):
        client_socket.send(b"upload")
        client_socket.recv(1024)  # Receive ready message from server
        client_socket.send(filename.encode())
        with open(filename, 'rb') as file:
            file_data = file.read(1024)
            while file_data:
                client_socket.send(file_data)
                file_data = file.read(1024)
        print(f"File {filename} uploaded successfully.")
    else:
        print("File not found on client.")

def download_file(client_socket):
    """Download a file from the server."""
    filename = input("Enter the name of the file to download: ")
    client_socket.send(b"download")
    client_socket.recv(1024)  # Receive ready message from server
    client_socket.send(filename.encode())
    
    server_response = client_socket.recv(1024).decode()
    if server_response == "File not found on server.":
        print(server_response)
    else:
        with open(f"downloaded_{filename}", 'wb') as file:
            file_data = client_socket.recv(1024)
            while file_data:
                file.write(file_data)
                file_data = client_socket.recv(1024)
        print(f"File {filename} downloaded successfully.")

def start_client(host='127.0.0.1', port=65432):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))
    print(client_socket.recv(1024).decode())

    while True:
        action = input("Do you want to upload or download a file? (upload/download/exit): ").lower()
        if action == 'upload':
            upload_file(client_socket)
        elif action == 'download':
            download_file(client_socket)
        elif action == 'exit':
            break
        else:
            print("Invalid action. Please choose 'upload', 'download', or 'exit'.")

    client_socket.close()

if __name__ == "__main__":
    start_client()
