import socket

def connect_to_server(server_ip, server_port):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((server_ip, server_port))
    print(client_socket.recv(1024).decode())
    return client_socket

def send_command(client_socket, command):
    client_socket.send(command.encode())
    response = client_socket.recv(1024).decode()
    print(response)
    return response

def main():
    server_ip = input("Enter server IP: ")
    server_port = int(input("Enter server port: "))
    
    client_socket = connect_to_server(server_ip, server_port)
    
    while True:
        command = input("ftp> ")
        if command.lower() == "quit":
            break
        elif command.startswith("RETR"):
            _, filename = command.split()
            send_command(client_socket, command)
            with open(filename, 'wb') as f:
                while True:
                    data = client_socket.recv(1024)
                    if data.endswith(b"EOF"):
                        f.write(data[:-3])
                        break
                    f.write(data)
        elif command.startswith("STOR"):
            _, filename = command.split()
            try:
                with open(filename, 'rb') as f:
                    client_socket.send(command.encode())
                    client_socket.sendall(f.read())
                client_socket.send(b"EOF")
            except FileNotFoundError:
                print(f"File {filename} not found.")
        else:
            send_command(client_socket, command)
    
    client_socket.close()

if __name__ == "__main__":
    main()
