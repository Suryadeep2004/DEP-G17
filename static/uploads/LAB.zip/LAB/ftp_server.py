import socket
import threading
import os

# Directory structure
BASE_DIR = './ftp_server'
DATA_DIR = os.path.join(BASE_DIR, 'data')
LOG_DIR = os.path.join(BASE_DIR, 'logs')
LOG_FILE = os.path.join(LOG_DIR, 'server.log')

# Create directories if not exist
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

# Logging function
def log_message(message):
    with open(LOG_FILE, 'a') as log_file:
        log_file.write(message + '\n')

# Handle client requests
def handle_client(client_socket, client_address):
    client_socket.send(f"Welcome Client {client_address[0]} to the FTP Server".encode())
    
    authenticated = False
    
    while True:
        try:
            command = client_socket.recv(1024).decode()
            if not command:
                break
            
            if not authenticated:
                if command.startswith("LOGIN"):
                    _, username, password = command.split()
                    # Dummy user authentication
                    if username == "user" and password == "password":
                        client_socket.send("Login successful.".encode())
                        authenticated = True
                    else:
                        client_socket.send("Invalid credentials.".encode())
                        continue
                else:
                    client_socket.send("Please login first using LOGIN <username> <password>".encode())
                    continue
            
            # LIST command
            elif command == "LIST":
                files = os.listdir(DATA_DIR)
                file_list = "\n".join(files) if files else "No files in the directory."
                client_socket.send(file_list.encode())
            
            # RETR command
            elif command.startswith("RETR"):
                _, filename = command.split()
                filepath = os.path.join(DATA_DIR, filename)
                if os.path.exists(filepath):
                    with open(filepath, 'rb') as f:
                        client_socket.sendall(f.read())
                    client_socket.send("EOF".encode())  # To signal the end of file
                else:
                    client_socket.send(f"File {filename} not found.".encode())
            
            # STOR command
            elif command.startswith("STOR"):
                _, filename = command.split()
                filepath = os.path.join(DATA_DIR, filename)
                with open(filepath, 'wb') as f:
                    while True:
                        data = client_socket.recv(1024)
                        if data.endswith(b"EOF"):
                            f.write(data[:-3])  # Remove EOF
                            break
                        f.write(data)
                client_socket.send(f"File {filename} uploaded successfully.".encode())
            
            # Server-to-server file transfer
            elif command.startswith("SEND"):
                _, target_server, target_port, filename = command.split()
                filepath = os.path.join(DATA_DIR, filename)
                if os.path.exists(filepath):
                    target_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    target_socket.connect((target_server, int(target_port)))
                    target_socket.send(f"STOR {filename}".encode())
                    with open(filepath, 'rb') as f:
                        target_socket.sendall(f.read())
                    target_socket.send(b"EOF")
                    target_socket.close()
                    client_socket.send(f"File {filename} sent to server {target_server}:{target_port}".encode())
                else:
                    client_socket.send(f"File {filename} not found.".encode())
            
            # Unknown command
            else:
                client_socket.send("Unknown command.".encode())
        except Exception as e:
            log_message(f"Error handling client {client_address}: {e}")
            break
    
    client_socket.close()
    log_message(f"Connection closed with {client_address}")

# Main server function
def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("0.0.0.0", 2121))
    server_socket.listen(5)
    print("FTP server started on port 2121")
    log_message("FTP server started.")
    
    while True:
        client_socket, client_address = server_socket.accept()
        log_message(f"New connection from {client_address}")
        client_handler = threading.Thread(target=handle_client, args=(client_socket, client_address))
        client_handler.start()

if __name__ == "__main__":
    start_server()
